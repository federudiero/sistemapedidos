import { useProvincia } from "@/context/ProvinciaContext";
import { useUsuariosProvincia } from "@/hooks/useUsuariosProvincia";

export default function UsuariosProvinciaPanel() {
  const { provincia } = useProvincia();
  const { admins, vendedores, repartidores } = useUsuariosProvincia(provincia);

  if (!provincia) {
    return (
      <div className="alert alert-warning">
        Primero seleccioná una provincia para ver usuarios.
      </div>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-3">
      <RolCard titulo="Administradores" items={admins} badge="admin" />
      <RolCard titulo="Vendedores" items={vendedores} badge="vendedor" />
      <RolCard titulo="Repartidores" items={repartidores} badge="repartidor" />
    </div>
  );
}

function RolCard({ titulo, items, badge }) {
  return (
    <div className="shadow-lg card bg-base-200">
      <div className="card-body">
        <h2 className="card-title">
          {titulo} <div className="badge badge-secondary">{items.length}</div>
        </h2>
        <ul className="mt-2 space-y-2">
          {items.map((u) => (
            <li key={u.id} className="flex items-center justify-between">
              <div>
                <p className="font-medium">{u.displayName || u.email}</p>
                <p className="text-xs opacity-70">{u.email}</p>
              </div>
              <div className="badge">{badge}</div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
