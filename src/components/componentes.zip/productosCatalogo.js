export const productosCatalogo = [
  { nombre: "LÁTEX BLANCO 20L Económico", precio: 24700 },
  { nombre: "LÁTEX BLANCO 20L Premium", precio: 36500 },
  { nombre: "LÁTEX BLANCO 20L Lavable", precio: 39500 },
  { nombre: "LÁTEX BLANCO 20L Superior", precio: 43000 },

  { nombre: "Combo latex Económico + rodillo + enduido 20L ", precio: 28000 },
  { nombre: "Combo latex Económico + rodillo + enduido + fijador 20L ", precio: 29500 },
  { nombre: "Combo latex Premium + rodillo + enduido 20L ", precio: 39500 },
  { nombre: "Combo latex Lavable + rodillo + enduido 20L ", precio: 43500 },
  { nombre: "Combo latex Superior + rodillo + enduido 20L ", precio: 47000 },
  { nombre: "Combo membrana liquida + rodillo + venda 20L ", precio: 37500 },

  { nombre: "Enduido x Xl ", precio: 3000 },
  { nombre: "Enduido x 4lts ", precio: 10000 },
  { nombre: "Enduido x 10lts ", precio: 21000 },
  { nombre: "Enduido x 20lts ", precio: 42500 },

  { nombre: "Fijador x Xl ", precio: 3000 },
  { nombre: "Fijador x 4lts ", precio: 10000 },
  { nombre: "Fijador x 10lts ", precio: 21000 },
  { nombre: "Fijador x 20lts ", precio: 42500 },
  
   { nombre: "Membrana líquida", precio: 33500 },
   { nombre: "Membrana pasta", precio: 39500 },
   { nombre: "Membrana Roja/Gris", precio: 42500 },
  { nombre: "Membrana líquida 20L + rodillo + venda", precio: 37500 },
  { nombre: "Membrana pasta 20L + rodillo + venda", precio: 43500 },
  { nombre: "Membrana Rojo teja/gris 20L + rodillo + venda", precio: 46500 },

  { nombre: "Rodillo Semi lana 22 cm", precio: 3300 },

  { nombre: "LÁTEX COLOR Naranja 4L", precio: 21000 },
  { nombre: "LÁTEX COLOR Naranja 10L", precio: 33000 },
  { nombre: "LÁTEX COLOR Naranja 20L", precio: 55000 },

  { nombre: "LÁTEX COLOR Rosa 4L", precio: 21000 },
  { nombre: "LÁTEX COLOR Rosa 10L", precio: 33000 },
  { nombre: "LÁTEX COLOR Rosa 20L", precio: 55000 },

  { nombre: "LÁTEX COLOR Rojo 4L", precio: 21000 },
  { nombre: "LÁTEX COLOR Rojo 10L", precio: 33000 },
  { nombre: "LÁTEX COLOR Rojo 20L", precio: 55000 },

  { nombre: "LÁTEX COLOR Rojo teja 4L", precio: 21000 },
  { nombre: "LÁTEX COLOR Rojo teja 10L", precio: 33000 },
  { nombre: "LÁTEX COLOR Rojo teja 20L", precio: 55000 },

  { nombre: "LÁTEX COLOR Ocre  4L", precio: 21000 },
  { nombre: "LÁTEX COLOR Ocre  10L", precio: 33000 },
  { nombre: "LÁTEX COLOR Ocre  20L", precio: 55000 },


  { nombre: "LÁTEX COLOR Avena  4L", precio: 21000 },
  { nombre: "LÁTEX COLOR Avena  10L", precio: 33000 },
  { nombre: "LÁTEX COLOR Avena  20L", precio: 55000 },

  { nombre: "LÁTEX COLOR Amarillo  4L", precio: 21000 },
  { nombre: "LÁTEX COLOR Amarillo  10L", precio: 33000 },
  { nombre: "LÁTEX COLOR Amarillo  20L", precio: 55000 },

  { nombre: "LÁTEX COLOR Verde Manzana  4L", precio: 21000 },
  { nombre: "LÁTEX COLOR Verde Manzana  10L", precio: 33000 },
  { nombre: "LÁTEX COLOR Verde Manzana  20L", precio: 55000 },

  { nombre: "LÁTEX COLOR Verde Esmeralda  4L", precio: 21000 },
  { nombre: "LÁTEX COLOR Verde Esmeralda  10L", precio: 33000 },
  { nombre: "LÁTEX COLOR Verde Esmeralda  20L", precio: 55000 },

  { nombre: "LÁTEX COLOR Turquesa 4L", precio: 21000 },
  { nombre: "LÁTEX COLOR Turquesa  10L", precio: 33000 },
  { nombre: "LÁTEX COLOR Turquesa  20L", precio: 55000 },

  { nombre: "LÁTEX COLOR Gris  4L", precio: 21000 },
  { nombre: "LÁTEX COLOR Gris  10L", precio: 33000 },
  { nombre: "LÁTEX COLOR Gris  20L", precio: 55000 },

  { nombre: "LÁTEX COLOR Negro  4L", precio: 21000 },
  { nombre: "LÁTEX COLOR Negro  10L", precio: 33000 },
  { nombre: "LÁTEX COLOR Negro  20L", precio: 55000 },

  { nombre: "Entonador 125ml", precio: 2500 },
  { nombre: "Promo x2 o mas Entonadores", precio: 2000 },

  { nombre: "Envio1", precio: 3500 },
  { nombre: "Envio2", precio: 4000 },
  { nombre: "Envio3", precio: 4500 },
  { nombre: "Envio4", precio: 5000 },


];